---
layout: default
title: News Bias Detection with XAI
permalink: /case-studies/news-bias-xai/
---

# 📰 News Bias Detection with XAI

This case study examines how InterXAI can detect and critique potential bias in machine-generated news summaries.

## 🗞️ Sample Headline

**Original Article:**  
"Government Proposes New Education Bill to Improve National Curriculum"

**GPT Summary:**  
"The administration proudly announced a reform to fix the broken education system."

---

## 🤖 Machine Explanation

GPT-4 justifies the wording as a simplification for clarity. It identifies the phrase *"broken education system"* as a metaphor inferred from policy criticism trends, aiming to resonate with reader sentiment.

- **Focus:** Predictive phrasing based on learned news tone
- **Strength:** Streamlined communication
- **Limitation:** May introduce unverified bias or tone

---

## 🧠 Human Intertextual Critique

A media critic compares the summary with prior headlines from partisan outlets, noting similarities in emotionally charged terms like "broken" and "proudly." The critique traces this phrasing back to campaign rhetoric, questioning the neutrality of the summary.

- **Focus:** Historical intertextual patterns and ideological framing
- **Strength:** Highlights embedded value judgments
- **Limitation:** Requires domain-specific knowledge

---

## 🔍 Takeaway

Explainable AI needs human-centered, intertextual oversight to ensure fair and context-aware representations—especially in public discourse.

➡️ See more examples on [InterXAI Case Studies](/case-studies/)
